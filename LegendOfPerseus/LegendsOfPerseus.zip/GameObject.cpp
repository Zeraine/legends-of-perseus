#include "stdafx.h"
#include "GameObject.h"

int GameObject::screenHeight = 480;
int GameObject::screenWidth = 853;